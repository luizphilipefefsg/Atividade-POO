﻿using System;
using System.Collections.Generic;

namespace ControleBiblioteca
{
    // Classe Livro
    public class Livro
    {
        public string Titulo;
        public string Autor;
        public int AnoPublicacao;
        public bool Disponivel; // Atributo obrigatório

        // Construtor padrão
        public Livro()
        {
            Titulo = "Sem título";
            Autor = "Desconhecido";
            AnoPublicacao = 0;
            Disponivel = true;
        }

        // Construtor com parâmetros
        public Livro(string titulo, string autor, int anoPublicacao)
        {
            Titulo = titulo;
            Autor = autor;
            AnoPublicacao = anoPublicacao;
            Disponivel = true;
        }

        // Método para emprestar o livro
        public void Emprestar()
        {
            if (Disponivel)
            {
                Disponivel = false;
            }
            else
            {
                Console.WriteLine($"O livro '{Titulo}' já está emprestado.");
            }
        }

        // Método para exibir detalhes do livro
        public void ExibirDetalhes()
        {
            string situacao = Disponivel ? "Disponível" : "Emprestado";
            Console.WriteLine($"Título: {Titulo} | Autor: {Autor} | Ano: {AnoPublicacao} | Situação: {situacao}");
        }
    }

    // Classe Aluno
    public class Aluno
    {
        public string Nome;
        public string Matricula;
        public string Turma;

        // Construtor padrão
        public Aluno()
        {
            Nome = "Novo Aluno";
            Matricula = "0000000";
            Turma = "Nenhuma";
        }

        // Construtor com parâmetros
        public Aluno(string nome, string matricula, string turma)
        {
            Nome = nome;
            Matricula = matricula;
            Turma = turma;
        }

        // Método para exibir dados do aluno
        public void ExibirDados()
        {
            Console.WriteLine($"Nome: {Nome} | Matrícula: {Matricula} | Turma: {Turma}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Criando lista de livros
            List<Livro> livros = new List<Livro>();

            // Instanciando 3 livros (Requisito: pelo menos um padrão e um com parâmetros)
            Livro livro1 = new Livro(); // Padrão
            Livro livro2 = new Livro("Dom Casmurro", "Machado de Assis", 1899);
            Livro livro3 = new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry", 1943);

            // Instanciando 2 alunos
            Aluno aluno1 = new Aluno("Ana Souza", "2026001", "Informática");
            Aluno aluno2 = new Aluno(); // Padrão

            // Simulando um empréstimo
            livro3.Emprestar();

            // Adicionando à lista
            livros.Add(livro1);
            livros.Add(livro2);
            livros.Add(livro3);

            // Exibição dos resultados
            Console.WriteLine("--- LISTA DE LIVROS CADASTRADOS ---");
            foreach (Livro livro in livros)
            {
                livro.ExibirDetalhes();
            }

            Console.WriteLine("\n--- ALUNO RESPONSÁVEL PELO EMPRÉSTIMO ---");
            aluno1.ExibirDados();

            Console.WriteLine("\n\nPressione qualquer tecla para sair...");
            Console.ReadKey();
        }
    }
}